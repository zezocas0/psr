#!/usr/bin/env python
import json
import cv2
from colorama import Fore, Style

import numpy as np

def nothing(x):
    pass


def main():
    # initial setup
    window_name = "Color Segmenter"
    capture = cv2.VideoCapture(0)
    cv2.namedWindow(window_name, cv2.WINDOW_AUTOSIZE)

    limits = {
        "limits": {
            "B": {"max": 200, "min": 100},
            "G": {"max": 200, "min": 100},
            "R": {"max": 200, "min": 100},
        }
    }    
    cv2.createTrackbar("B_minimo", window_name, 0, 255, nothing)
    cv2.createTrackbar("B_maximo", window_name, 0, 255, nothing)
    
    cv2.createTrackbar("G_minimo", window_name, 0, 255, nothing)
    cv2.createTrackbar("G_maximo", window_name, 0, 255, nothing)


    cv2.createTrackbar("R_minimo", window_name, 0, 255, nothing)
    cv2.createTrackbar("R_maximo", window_name, 0, 255, nothing)
    


  
    
   


    while True:
        _, image = capture.read()  # get an image from the camera


        b_img, g_img, r_img = cv2.split(image)

        b_min = cv2.getTrackbarPos("B_minimo", window_name)
        b_max = cv2.getTrackbarPos("B_maximo", window_name)
        
        print(b_min,b_max)
        g_min = cv2.getTrackbarPos("G_minimo", window_name)
        g_max = cv2.getTrackbarPos("G_maximo", window_name)
    
        r_min = cv2.getTrackbarPos("R_minimo", window_name)
        r_max = cv2.getTrackbarPos("R_maximo", window_name)


        
        # lower=np.array([r_min,g_min,b_min])
        # # upper=np.array([r_max,g_max,b_max])
        # lower=np.array([0,60,0])
        # upper=np.array([50,256,50])
        # thresholded_gray=cv2.inRange(image,lower,upper)


        _, b_thresholded = cv2.threshold(b_img, b_min,b_max, cv2.THRESH_BINARY)
        _, g_thresholded = cv2.threshold(g_img, g_min,g_max, cv2.THRESH_BINARY)
        _, r_thresholded = cv2.threshold(r_img, r_min,r_max, cv2.THRESH_BINARY)
        


        thresholded = cv2.merge([b_thresholded, g_thresholded, r_thresholded])

        thresholded_gray=cv2.cvtColor(thresholded,cv2.COLOR_RGB2GRAY)
        # Visualization
        
        cv2.imshow(window_name, thresholded_gray)
        pressed_key = cv2.waitKey(30)

        if pressed_key == -1:
            pass
        elif chr(pressed_key) == "q":  # Quite the program
            exit(0)
        elif chr(pressed_key) == "w":  # Clear the drawing
            file_name = "limits.json"
            with open(file_name, "w") as file_handle:
                print("writing dictionary d to file " + file_name)
                limits = {
                        "limits": {
                            "B": {"max": b_max, "min": b_min},
                            "G": {"max": g_max, "min": g_min},
                            "R": {"max": r_max, "min": r_min},
                        }
                    }    
                json.dump(limits, file_handle)  # d is the dicionary
                print(Fore.BLUE + "Write!" + Style.RESET_ALL)


if __name__ == "__main__":
    main()
