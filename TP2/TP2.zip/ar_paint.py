#!/usr/bin/env python3
import json

import cv2
from colorama import Fore, Style
import argparse
from cv2 import threshold
import numpy as np



def painting(val):
    print (val["limits"])
    limits=val["limits"]
    #limite B,G,R
    b=limits["B"];g=limits["G"];r=limits["R"]

    #min and max values of each color
    b_max=b["max"];b_min=b["min"]
    g_max=g["max"];g_min=g["min"]
    r_max=r["max"];r_min=r["min"]
    
    capture=cv2.VideoCapture(0)
    while True:
        _,image=capture.read()
        cv2.imshow("captured video",image)

        b_img, g_img, r_img = cv2.split(image)
        _, b_thresholded = cv2.threshold(b_img, b_min,b_max, cv2.THRESH_BINARY)
        _, g_thresholded = cv2.threshold(g_img, g_min,g_max, cv2.THRESH_BINARY)
        _, r_thresholded = cv2.threshold(r_img, r_min,r_max, cv2.THRESH_BINARY)
        thresholded=cv2.merge([b_thresholded,g_thresholded,r_thresholded])
        thresholded_gray=cv2.cvtColor(thresholded,cv2.COLOR_RGB2GRAY)        
        
        cv2.imshow("video",thresholded_gray)
        
        #quadro branco
        img_1 = np.zeros([512,512,1],dtype=np.uint8)
        img_1.fill(255)
        cv2.imshow("whiteboard",img_1)
        
        #check mean coordinates of the thresholded image 
        M = cv2.moments(thresholded_gray)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
            print(cX,cY)
            
            #draw on the whiteboard
            cv2.circle(img_1,(cX,cY),5,(0,0,0),-1)
            cv2.imshow("whiteboard",img_1)
        else:
            print("no object detected")
        

        pressed_key=cv2.waitKey(30)
        if pressed_key == -1:
            pass
        elif chr(pressed_key) == "q":  # Quite the program
            exit(0)
        elif chr(pressed_key) == "w":  # Clear the drawing
            pass









def main():
    # usar argparse para fazer o ui para o user interagir
    parser= argparse.ArgumentParser()

    parser.add_argument( "-j" ,"--json",type=str
    , help="full path to the json file")
    # parser.add_argument("-h",help=" show this help message and exit")
    
    
    args= parser.parse_args()


    if args.json ==str :
        print("the path of 'limits.json' was not correct")
    else: 
        f=open(args.json)
        limits=json.load(f)

        painting(limits)

if __name__ == '__main__':
    main()  